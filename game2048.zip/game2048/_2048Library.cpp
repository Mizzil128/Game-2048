#include "_2048Header.h"
#include <algorithm>
#include <iostream>
#include <sstream>
#include <utility>
#include <cmath>
#include <cstdlib>

float clampf ( float v, float a, float b ) 	{ return v < a ? a : ( v > b ? b : v ); }


float lerp ( float a, float b, float t ) 	{ return a + (b - a) * t; }

Vector2 lerpv (const Vector2 &a, const Vector2 &b, float t) {  return Vector2 { lerp(a.x, b.x, t), lerp(a.y, b.y, t) }; }

float easeOut (float t) {
	
	t =clampf( t, 0.0f, 1.0f );
	return 1.0f - (1.0f - t) * (1.0f - t);
}

int Board::getScore() const {
	
	return score;
}

void Board::writeToStream( std::ostream &os ) const {
	
	os << size << " " << score << "\n";
	
	for ( int r =0; r <size; r++) {
		
		for ( int c =0; c <size; ++c) {
			
			os << grid[r][c];
			
				if ( c + 1 <size )  os << " ";
		}
				
		    os << "\n";
	} 
		
}

bool Board::loadFromStream ( std::istream &is ) {
	
	int fileSize  =0;
	int fileScore =0;
			
	if ( !(is >> fileSize >> fileScore) )  return false;
	
		if ( fileSize != size ) {
			//unexpected size : refuse to load (avoid mismatch)
			return false;
		
		}
			
		std::vector<std::vector<int>> newGrid( size, std::vector<int>( size, 0) );
		
		for ( int r =0; r <size; r++ ) {
			
			for ( int c =0; c <size; ++c ) {
				
				if ( !(is >> newGrid[r][c]) )  return false;        //failed to read expected ints
				
				}
			}
			
			//successful read -> apply to board
			grid     =newGrid;
			prevGrid =grid;
			score    =fileScore;
			rebuildSpritesFromGrid(LEFT);  //refresh sprites (no slide)
			return true;
	
}

bool Board::saveToFile( const std::string &path ) const {
	
	std::ofstream ofs{ path.c_str() };
	if (!ofs)  return false;
			
	writeToStream(ofs);
	ofs.close();
	return true;

}

bool Board::loadFromFile( const std::string &path ) {
	
	std::ifstream ifs( path.c_str() );
	if (!ifs)  return false;
	
	bool ok =loadFromStream(ifs);
	ifs.close();
	return ok;
	
}

void Board::spawnRandomTile() {
	
	std::vector<Vec2i> emptycells;
		
	for( int r =0; r <size; ++r )

		for( int c =0; c <size; c++ )
		
		    if( grid[r][c] == 0 )  emptycells.push_back( Vec2i(r, c) );

	//	if( emptycells.empty() )  return;

        if( !emptycells.empty() ) {
	        Vec2i pos =emptycells[ std::rand() % emptycells.size() ];
			//90% chance of 2, 10% chance of 4
            grid[pos.x][pos.y] = (std::rand() % 10 < 9) ? 2 : 4;	
        }
}

bool Board::move( Direction dir ) {
	
	//keep prevGrid detect spawn/merge to help animation decisions
	prevGrid = grid;

	bool moved =false; //merged = false;

	if(dir == LEFT)        moved =moveLeft();
	else if(dir == RIGHT)  moved =moveRight();
	else if(dir == UP)     moved =moveUp();
	else if(dir == DOWN)   moved =moveDown();

	if(moved) {
				
	    spawnRandomTile();
		rebuildSpritesFromGrid(dir);
	}
		    
	return moved;
}

bool Board::moveLeft() {
	
	bool moved =false;
			
	for ( int r =0; r <size; ++r ) {
				
		std::vector<int> line;
				
		for( int c =0; c <size; c++ ) 
			if ( grid[r][c] !=0)  line.push_back(grid[r][c] );
				   
		for( int i =0; i <(int)line.size() - 1; i++ ){
		
			if( line[i] == line[i + 1] ) {
				line[i] *=2;
				score   += line[i];
				line.erase( line.begin() + i + 1 );
							//merged =true;
			}
		}
					
		while( (int)line.size() < size )  line.push_back(0);
					
		for( int c =0; c <size; ++c ) {
			if ( grid[r][c] != line[c] )  moved = true;
						
			grid[r][c] = line[c];
		}
	}

	return moved;
}

bool Board::moveRight() {
	
	bool moved =false;
	
	for( int  r =0; r <size; r++ ) {
				
		std::vector<int> line;
				
		for ( int c =size - 1; c >=0; --c ) 
			if ( grid[r][c] !=0 )  line.push_back(grid[r][c]);
					
		for ( int i =0; i <(int)line.size() - 1; ++i ) {

			if( line[i] == line[i + 1] ) {
		        line[i] *=2;
		        score   +=line[i];
		        line.erase( line.begin() + i + 1 );
					        //merged =true;
			}
	    }
				    
		while ( (int)line.size() <size )  line.push_back(0);
				
		for( int c =size - 1, i =0; c >=0; --c, ++i ) {
			if( grid[r][c] != line[i] )  moved = true;
					
			grid[r][c] = line[i];
		}
	}

	return moved;
}

bool Board::moveUp() {
	
	bool moved =false;
	
	for( int  c =0; c <size; c++ ) {
				
		std::vector<int> line;
				
		for ( int r =0; r <size; ++r ) 
			if ( grid[r][c] !=0 )  line.push_back( grid[r][c] );
				
		for ( int i =0; i <(int)line.size() - 1; ++i ) {
		
			if( line[i] == line[i + 1] ){
		        line[i] *=2;
			    score   +=line[i];
		        line.erase( line.begin() + i + 1 );
					     //   merged =true;
		    }
		}
				
		while ( (int)line.size() <size )  line.push_back(0);
				
		for( int r =0; r <size; ++r ) {
			if ( grid[r][c] != line[r] )  moved =true;
	
		grid[r][c] =line[r];
		}
	}

	return moved;
}

bool Board::moveDown() {
	
	bool moved =false;
			
	for( int c =0; c <size; c++ ) {
			
		std::vector<int> line;
				
		for ( int r =size - 1; r >=0; --r )  
			if ( grid[r][c] !=0 )  line.push_back( grid[r][c] );
					
		for ( int i =0; i <(int)line.size() - 1; ++i ) {
			
			if( line[i] == line[i + 1] ) {
		        line[i] *=2;
		        score   += line[i];
		        line.erase( line.begin() + i + 1 );
					        //merged =true;
			}
		}
				    
		while ( (int)line.size() <size )  line.push_back(0);
				
		for( int r =size - 1, i =0; r >=0; --r, i++ ) {
			if ( grid[r][c] != line[i] )  moved =true;
		
		    grid[r][c] =line[i];
		}
	}

	return moved;
}

bool Board::has2048() const {
	
	for ( int r =0; r <size; ++r )
		for ( int c =0; c <size; c++ ) 
			if ( grid[r][c] == 2048 )  return true;     // later here checks if user wants to continue after 2048 (play onward 2048)
			
	return false;
}

bool Board::hasMoves() const {
	
	for ( int r =0; r <size; ++r )
		for ( int c =0; c <size; ++c )
	        if ( grid[r][c] == 0 ) return true;
			        
	for ( int r =0; r <size; ++r )
	    for ( int c =0; c <size - 1; ++c )
	        if ( grid[r][c] == grid[r][c + 1] ) return true;
			        
	for ( int c =0; c <size; ++c )
	    for( int r =0; r <size - 1; ++r )
		    if ( grid[r][c] == grid[r + 1][c] ) return true;
				   
	return false;
}

void Board::rebuildSpritesFromGrid( Direction moveDir) {
	
	sprites.clear();
        	
			//detection a newly spawned tile, compare prevGrid vs grid.
    Vec2i spawnPos( -1, -1 );
    for ( int r =0; r <size; ++r )
        for ( int c =0; c <size; ++c )
            if ( prevGrid[r][c] == 0 && grid[r][c] != 0 )  spawnPos = Vec2i(r, c);   //last found spawn (there's only 1 per move)
        	        
        	        
					//creating sprite entries for every non-zero cell.
        	        //for each new tile, we set an entry with targetPos at ists cell, and startPos offset
        	        //according to the move direction so it looks like it slid in
    for ( int r =0; r <size; ++r ) {
        for ( int c =0; c <size; ++c ) {
        	        		
			int v = grid[r][c];
        	if( v == 0 )  continue;
        	        		
			TileSprite s;
			s.value = v;	
							
							//compute pixel top-left for cell 
			Vector2 target =cellTopLeft(c, r);
			s.targetPos    =target;
			s.startPos     =target;     //default: no slide
			s.moveT        =1.0f;
			s.moveDuration =popDuration;
			s.scaleStart   =1.0f;
			s.scaleTarget  =1.0f;
			s.active       =true;
							
							//if this tile is the one just spawned, animate pop from scale 0
			if ( spawnPos.x == r && spawnPos.y == c ) {
				s.scaleT        =0.0f;
				s.scaleStart    =0.0f;
				s.scaleTarget   =1.0f;
				s.scaleDuration =popDuration;
							
			} else {
							
								//for slide: offset startPos from target in opposite direction of motion
				Vector2 offset = { 0, 0};
				float off =(float)cellSize + (float)gap;
								
				if (moveDir == LEFT)   offset.x =off;
				if (moveDir == RIGHT)  offset.x =-off;
				if (moveDir == UP)     offset.y =off;
				if (moveDir == DOWN)   offset.y =-off;
								
								
								//to detect merges: if value increased at this cell compared to prevGrid
								//likely resulted from a merge -> give a pop animation
				if ( prevGrid[r][c] < grid[r][c] ) {
								
					s.scaleT        =0.0f;
					s.scaleStart    =0.0f;
					s.scaleTarget   =1.15f;    //slightly larger 
					s.scaleDuration =popDuration;
				}
								
								//start position slightly offset so it animates in
				s.startPos =Vector2 { target.x + offset.x, target.y + offset.y };
				s.moveT    =0.0f;
			}
							
			sprites.push_back(s);
		}
	}
				
					//after rebuilding sprites, set prevGrid = grid so future spawns are detected relative to new state
	prevGrid = grid;
}

Vector2 Board::cellTopLeft ( int col, int row ) const {
	
	int boardW =size * (cellSize + gap) + gap;
        	//assume caller centers board; Board doesn't need to know screen size.
        	//but the fame will place hte board at particular startX/StartY.
        	//for sprite positions we return positions relative to board origin (0, 0)
        	//use actual absolute positions in game when drawing (add boardstart).
    float x =(float)(col * (cellSize + gap));
   	float y =(float)(row * (cellSize + gap));
   	return Vector2 { x, y };
}

void Board::updateAnimations ( float dt ) {
	
	for( size_t i =0; i <sprites.size(); ++i ) {
		TileSprite &s =sprites[i];
				
				//movement progress
		if( s.moveT < 1.0f ) {
					
			s.moveT =clampf( s.moveT + dt / s.moveDuration, 0.0f, 1.0f );
				
		}
				
				//scale progress
		if ( s.scaleT < 1.0f ) {
					
			s.scaleT =clampf( s.scaleT + dt / s.scaleDuration, 0.0f, 1.0f ); 
		}
	}
}

void Board::drawb ( int boardX, int boardY ) const {
	
		//background board rectangle
	DrawRectangle( boardX - gap, boardY - gap,
                   size * (cellSize + gap) + gap,
	               size * (cellSize + gap) + gap,
	               Color{187, 173, 160, 255} );

			//draw individual cells
	for( int r =0; r <size; ++r ) {
				
		for( int c =0; c <size; ++c ) {
					
			int x =boardX + c * (cellSize + gap);
			int y =boardY + r * (cellSize + gap);

			DrawRectangleRounded( Rectangle{ (float)x, (float)y,
				                  float(cellSize), (float)(cellSize) }, 0.15f, 8, 
					              Color { 205, 193, 180, 255 } );
					
                    
		}
	}
				
				//draw animated tiles (sprites).  compute current interpolated position (relative to board origin),
				//then offset by boardX/Y for absolute screen coordinates
				
	for( size_t i =0; i <sprites.size(); ++i ) {
					
		const TileSprite &s = sprites[i];
					
					//eased t for movement & scale
		float mt = easeOut(s.moveT);
		float st = easeOut(s.scaleT);
					
		Vector2 curRel = lerpv ( s.startPos, s.targetPos, mt );
		float curScale = lerp  ( s.scaleStart, s.scaleTarget, st );
					
					//convert to absolute top-left
		float w        =cellSize * curScale;
		float h        =cellSize * curScale;
		float offsetX  =(cellSize - w) * 0.5f;
		float offsetY  =(cellSize - h) * 0.5f;
					
		float drawX = boardX + curRel.x + offsetX;
		float drawY = boardY + curRel.y + offsetY;
					
					
					// tile background color depends on value
		Color tileColor =getTileColor(s.value);
		DrawRectangleRounded( Rectangle { drawX, drawY, w, h }, 0.12f, 8, tileColor );
					
					
					//number drawn centered on scaled rectangle
		std::stringstream ss; 
		ss << s.value;
		std::string text =ss.str();
					
					//font size relative to scaled tile
		int fontSize = (s.value < 100) ? (int)(36 * curScale) : (s.value < 1000 ? (int)(30 * curScale) : (int)(24 * curScale));
			
		if ( fontSize < 8 ) fontSize =8;
			
		Vector2 textSize =MeasureTextEx( GetFontDefault(), text.c_str(), (float)fontSize, 1.0f );
				
		DrawText ( text.c_str(), 
				 (int)(drawX + (w - textSize.x) / 2), 
				 (int)(drawY + (h - textSize.y) / 2), 
				 fontSize, (s.value <= 4 ? Color {119, 110, 101, 255} : WHITE) );
	}
}

Color Board::getTileColor ( int v ) const {
	
	switch (v) {

	    case 0    :return Color{205, 193, 180, 255};
	    case 2    :return Color{238, 228, 218, 255};
	    case 4    :return Color{237, 224, 200, 255};
	    case 8    :return Color{242, 177, 121, 255};
	    case 16   :return Color{245, 149, 99, 255};
	    case 32   :return Color{246, 124, 95, 255};
	    case 64   :return Color{246, 94, 59, 255};
	    case 128  :return Color{237, 207, 114, 255};
	    case 256  :return Color{237, 204, 97, 255};
	    case 512  :return Color{237, 200, 80, 255};
	    case 1024 :return Color{237, 197, 63, 255};
	    case 2048 :return Color{237, 194, 46, 255};

	    default: return Color{60, 58, 50, 255};
	}
}


void GameWrap::initG() {
	
	InitAudioDevice();
	moveSound   =LoadSound("merge.wav");
	mergeSound  =LoadSound("merge.wav");
	winSound    =LoadSound("over.wav");
	overSound   =LoadSound("over.wav");
	clickSound  =LoadSound("merge.wav");
				
	board =make_unique<Board>(4, 110, 12);
	state =MENU;
	
	boardStartX =0;
	boardStartY =140;
	bestScore =0;
				
				
	//IF LOAD FAILS, KEEP FRESH BOARD.			
    //if (!board)       board =make_unique<Board>(4, 110, 12);
	if ( loadAll() ) {
	  
	   updateBestScore();  
       board->rebuildSpritesFromGrid(Board::LEFT);
	}
}


void GameWrap::shutdownG() {
	
	saveAll();
	updateBestScore();
				
	UnloadSound(moveSound);
	UnloadSound(mergeSound);
	UnloadSound(winSound);
	UnloadSound(overSound);
	UnloadSound(clickSound);
	CloseAudioDevice();
}

void GameWrap::handleInput() {
    // quick debug trace (optional)
    
   // std::cerr << "[handleInput] state=" << state << "\n"
    	
        // -------------------------
        // Playing: only movement + playing controls
        // -------------------------
        if( state == PLAYING ) {
        	
        	if (!board) {
                // defensive fallback
                board = make_unique<Board>(4, 110, 12);
                updateBestScore();
                return;
            }

            // Movement: use ELSE-IF chain so only one move executes per frame
            bool moved = false;
            if      (IsKeyPressed(KEY_LEFT)  || IsKeyPressed(KEY_A)) moved = board->move(Board::LEFT);
            else if (IsKeyPressed(KEY_RIGHT) || IsKeyPressed(KEY_D)) moved = board->move(Board::RIGHT);
            else if (IsKeyPressed(KEY_UP)    || IsKeyPressed(KEY_W)) moved = board->move(Board::UP);
            else if (IsKeyPressed(KEY_DOWN)  || IsKeyPressed(KEY_S)) moved = board->move(Board::DOWN);

            if (board && moved) {
                // play and update after move
                PlaySound(moveSound);
                updateBestScore();           
                board->rebuildSpritesFromGrid(Board::LEFT);     //sprites rebuild in board->move when moved == true
                
			} 

            // Only check win/lose if there was no load in this frame and board exists
            if (board->has2048()) {
                PlaySound(winSound);
                updateBestScore();
                state = WON;
                std::cout << "[STATE] -> WON\n";
                return;
            }

            if (!board->hasMoves()) {
                PlaySound(overSound);
                updateBestScore();
                state = OVER;
                std::cout << "[STATE] -> OVER\n";
                return;
            }
        }

            // Save / Load keys while playing (don't change state)
            if ( IsKeyPressed(KEY_X) ) {
            	
                if (saveAll()) {
                    // print absolute path for clarity (see saveAll change below)
                    std::cout << "[INFO] Game saved to: " << savePath << "\n";
                } else {
                    std::cout << "[WARN] Save failed\n";
                }
            }

            if (IsKeyPressed(KEY_L)) {
                if ( (state == PLAYING || state == MENU) && loadAll() ) {
                    updateBestScore();
                    board->rebuildSpritesFromGrid(Board::LEFT);
					if (state == MENU ) state =PLAYING;
					std::cout << "[INFO] Game loaded from: " << savePath << "\n";
					// After loading, don't immediately test hasMoves() in same frame.
                } else {
                    std::cout << "[WARN] Load failed or no save file\n";
                    return;
                }
            }
            return;
}


void GameWrap::updateMenu() {
	
	if (!board) {
                // defensive: if board is not set, create a new board instead of crashing
        std::cerr << "[ERROR] PLAYING but board is null -> creating new board\n";
        board =make_unique<Board>(4, 110, 12);
        updateBestScore();
        
       return; // wait next frame to avoid immediate checks
    }
	
	if ( IsKeyPressed(KEY_ENTER) ) {
        
        state =PLAYING;
        std::cout << "[STATE] -> PLAYING (ENTER)\n";
        updateBestScore();
        
        //ensures sprites up-to-date
        if (board)  board->rebuildSpritesFromGrid(Board::LEFT);
        else std::cout << "[INFO] -> CREATING SPRITE ISSUE\n";
	
	}else if (IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_Q)) {
        
		state = EXIT;
        std::cout << "[STATE] -> EXIT\n";
        return;
    }
    
    return;
}


void GameWrap::updatePaused() {
	
	if ( ( IsKeyPressed(KEY_P) || IsKeyPressed(KEY_ESCAPE) ) && state != PLAYING ) {
		
		PlaySound(clickSound);
		state =PLAYING;
		std::cout << "[STATE] -> playing (RESUME)\n";
	}
	
	else if ( IsKeyPressed(KEY_M) ) {             //go to main menu
					
	    PlaySound(clickSound);
	    state =MENU;
        std::cout << "[STATE] -> MENU\n";
    }
    return;
}

void GameWrap::updateGameOver( bool won ) {
	
	if ( IsKeyPressed(KEY_R) ) {
						
	    PlaySound(clickSound);
        board =make_unique<Board>(4, 110, 12);
        updateBestScore();
        state =PLAYING;
        std::cout << "[STATE] -> playing (RESTART)\n";
        return;
					
    }
	
	if ( IsKeyPressed(KEY_M) ) {
						
	    PlaySound(clickSound);
		state =MENU;
        std::cout << "[STATE] -> MENU (FROM WON/OVER)\n";
        return;
	
	} else {
		
		std::cout << "[INFO] -> HOLDING STATE PRESS R/M TO GO TO MENU\n";
		return;
	}
	return;
}


void GameWrap::updatePlaying( float dt ) {
	
	if ( ( IsKeyPressed(KEY_P) || IsKeyPressed(KEY_ESCAPE) ) ) {
					    
		PlaySound(clickSound);
        state =PAUSED;
        std::cout << "[STATE] -> PAUSED\n";
        return;
        
	}else if (board) {
	
	   board->updateAnimations(dt);
	//keep best score synchronize
	   updateBestScore();	
    
	} else  std::cout << "[INFO] -> COULDN'T UPDATE ANIMATIONS THERE'S SOME ISSUE IN UPDATE-ANIMATION LOGIC FROM BOARD OR MAY BE SOMEWHERE ELSE.";
	return;
}



void GameWrap::drawMenu() {

	const int screenWidth = 680;
	DrawText("2048", screenWidth/2 - 60, 100, 80, Color{119,110,101,255});
    DrawText("Press ENTER to Start", screenWidth/2 - 130, 240, 24, Color{80,80,80,255});
    DrawText("Press L to Continue (Load)", screenWidth/2 - 160, 280, 20, Color{100,100,100,255});
    DrawText("Press ESC OR Q to Quit", screenWidth/2 - 100, 320, 20, Color{120,120,120,255});
    std::stringstream bs;
	bs << "Best: " << bestScore;
    DrawText(bs.str().c_str(), screenWidth/2 - 60, 400, 24, Color{119,110,101,255});
	
}

void GameWrap::drawPaused() {
	const int screenWidth =680, screenHeight =720;
		
    if ( state == PAUSED ) {
        DrawRectangle(0,0,screenWidth,screenHeight,Color{0,0,0,150});
        DrawText("PAUSED", screenWidth/2 - 70, screenHeight/2 - 20, 36, WHITE);
        DrawText("P: Resume | M: Menu", screenWidth/2 - 120, screenHeight/2 + 30, 20, WHITE);
        return;
    } //else {
    	
    //	DrawRectangle(0,0,screenWidth,screenHeight,Color{0,0,0,150});
    //    DrawText("THERE'S A BUG", screenWidth/2 - 70, screenHeight/2 - 20, 36, WHITE);
	//}
}


void GameWrap::drawGameOver( bool won ) {
	const int screenWidth =680, screenHeight =720;
		
    if ( won ) {
               
        DrawRectangle(0, 0, screenWidth, screenHeight, Color{255,255,255,200} );
        DrawText( "You Win!", screenWidth/2 - 120, screenHeight/2 - 20, 48, Color{255,69,0,255} );
        DrawText( "R: Restart | M: Menu", screenWidth/2 - 120, screenHeight/2 + 40, 20, Color{80,80,80,255} );
               
	} else {
		
        DrawRectangle(0, 0, screenWidth, screenHeight, Color{0,0,0,180});
        DrawText("Game Over!", screenWidth/2 - 130, screenHeight/2 - 20, 48, Color{255,69,0,255});
        DrawText("R: Restart | M: Menu", screenWidth/2 - 120, screenHeight/2 + 40, 20, WHITE);
        return;
    }
    
    return;
}


void GameWrap::drawGameUI( int boardStartX, int boardStartY ) {
	const int screenWidth  =680, screenHeight =720;
	
	DrawText("2048 Game", 20, 20, 24, Color{119,110,101,255});
    DrawText("Arrows/WASD move, R restart, S save, \nL load, P pause, M menu", 20, 52, 16, Color{119,110,101,255});

                // Score boxes
    DrawRectangleRounded({480,20,180,60}, 0.3f, 8, Color{187,173,160,255});
                
	std::stringstream ss; 
    ss << ( board ? board->getScore() : 0 );
                
	DrawText(("Score: " + ss.str()).c_str(), 490, 32, 20, WHITE);
    DrawRectangleRounded({480,90,180,40}, 0.25f, 8, Color{200,200,200,255});
                
	std::stringstream bs;
	bs << bestScore;
                
	DrawText(("Best: " + bs.str()).c_str(), 490, 98, 18, Color{80,80,80,255});

    if (board)   board->drawb(boardStartX, boardStartY);
    else std::cout << "[WARN] -> NO BOARD CENTER WATCH LOGIC\n";
	               
}

bool GameWrap::saveAll() const {
	
	std::ofstream ofs{ savePath.c_str() };
	if (!ofs)  return false;
			
				//Single file format:
				//line1: bestScore
				//line2: board serialization (size score \n grid)
	ofs << bestScore << "\n";   
	board->writeToStream(ofs);
				
	ofs.flush();
	return ofs.good();
}

bool GameWrap::loadAll () {
	
	std::ifstream ifs{ savePath.c_str() };
    if (!ifs)  return false;
            	
            	//Expect 1st line: bestScore
    int fileBest =0;
            	
    if ( !(ifs >> fileBest) ) {
            		
		ifs.close();
   	    return false;
	}
				
	bestScore =fileBest;
	
	//checking/confirming/ensuring if board exists or not make fresh one
	if(!board)  board =make_unique<Board>(4, 110, 12);
	
	//board contains sprites align from load stream file
	bool ok =board->loadFromStream(ifs);
	ifs.close();
	
	//ensuring sprites align with loaded grid
	if(ok)   board->rebuildSpritesFromGrid(Board::LEFT);
	else     std::cout << "[WARN] -> COULDN'T BUILD SPRITES FROM LOADED GRID\n";
	
	return ok;
}

void GameWrap::updateBestScore() {
	
	if (board && board->getScore() > bestScore ) bestScore =board->getScore();
	else {
        std::cout << "[INFO] -> PREVIOUS SCORE IS BETTER THAN THIS SCORE\n";
	    return;
	}
	return;
}

GameWrap::GameWrap() { initG(); }
GameWrap::~GameWrap() { shutdownG(); }

void GameWrap::runG() {
	
	const int screenWidth  =680;
	const int screenHeight =720;
				
	InitWindow(screenWidth, screenHeight, "2048");
	SetExitKey(0);
	SetTargetFPS(60);
	
	boardStartX = ( screenWidth - (4 * (110) + (5 * 12)) ) / 2 + 12 ;		
	boardStartY =140;
	

	while( !WindowShouldClose() && state != EXIT ) {
					
					//get frame delta(in seconds since last frame)
		float dt =GetFrameTime();         //<-- frame delta used for timebased animatio 		
     	handleInput();
     	
     	switch (state) {
     		
     		case MENU: updateMenu(); break;
     		case PLAYING: updatePlaying(dt); break;
     		case PAUSED: updatePaused(); break;
     		case WON: updateGameOver(true); break;
     		case OVER: updateGameOver(false); break;
     		default: break;
		 }
		 
		BeginDrawing();
					
    	ClearBackground( Color {250, 248, 239, 255} );
		
    	if ( state == MENU ) {
		
		drawMenu();
	
    	} else {
		
		drawGameUI(boardStartX, boardStartY);
		if ( state == PAUSED )      drawPaused();
		else if ( state == WON )    drawGameOver(true);
		else if ( state == OVER )   drawGameOver(false);
    	} 	
	
    	EndDrawing();
	    
	}

	CloseWindow();
}
