#pragma once

#include "raylib.h"
#include <vector>
#include <memory>
#include <ctime>
#include <string>
#include <fstream>
                            
template<typename T, typename... Args>                        //make_unique<> is limited to std==C++14 so, it's alternative of it 
std::unique_ptr<T> make_unique(Args&&... args) {
    return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
}                            
    //--------------------------
	//Small helpers
	//--------------------------

struct Vec2i {
	
	int x, y;
	Vec2i ( int _x =0, int _y =0 ) : x(_x), y(_y) {}

};

static inline float clampf(float v, float a, float b);
static inline float lerp(float a, float b, float t);
static inline Vector2 lerpv(const Vector2 &a, const Vector2 &b, float t);
static inline float easeOut(float t);
	

    // ----------------------
   // Animated tile sprite
   // ----------------------
   
struct TileSprite {
	
	int value;
	Vector2 startPos;
	Vector2 targetPos;
	float moveT;
	float moveDuration;
	float scaleStart;
	float scaleTarget;
	float scaleT;
	float scaleDuration;
	bool active;
	
	TileSprite() : value(0), startPos{0, 0}, targetPos{0, 0},
	moveT(1.0f), moveDuration(0.12f), scaleStart(1.0f), scaleTarget(1.0f),
	scaleT(1.0f), scaleDuration(0.12f), active(false) {}
};


    // ----------------------
    // Board class with animation + robust serialization
    // ----------------------
    
class Board {
	
	private:
		int size;
		int cellSize;
		int gap;
		int score;
		std::vector<std::vector<int>> grid;
		std::vector<std::vector<int>> prevGrid;  //for detecting (spawn/merge)
		std::vector<TileSprite> sprites;
		const float moveDuration =0.12f;
		const float popDuration  =0.12f;
		
		public:
			Board( int s =4, int cell =10, int g =12) : size(s),
			cellSize(cell), gap(g), score(0) {
				
				grid.resize( size, std::vector<int>(size, 0) );
				prevGrid =grid;
				std::srand( (unsigned int)std::time(nullptr) );
				spawnRandomTile();               //spawn first tile 
				spawnRandomTile();               //spawn second tile
				rebuildSpritesFromGrid(LEFT);     
			}
			
			enum Direction { LEFT, RIGHT, UP, DOWN };
			
			int getScore() const;
			void writeToStream( std::ostream &os ) const;
			bool loadFromStream( std::istream &is );
			bool saveToFile( const std::string &path) const;
			bool loadFromFile( const std::string &path );
			void spawnRandomTile();
			bool move( Direction dir );
			bool moveLeft();
			bool moveRight();
			bool moveUp();
			bool moveDown();
			bool has2048() const;
			bool hasMoves() const;
			void rebuildSpritesFromGrid(Direction moveDir);
			Vector2 cellTopLeft(int col, int row) const;
			void updateAnimations(float dt);
			void drawb(int boardX, int boardY) const;
			
			private:
    		Color getTileColor(int v) const;
};

              
   //---------------------------------
    // Game wrapper + save / load integration
    //---------------------------------

class GameWrap {
	
	private:
		
		enum State { MENU, PLAYING, PAUSED, WON, OVER, EXIT };
		std::unique_ptr<Board> board;
		State state;
		int boardStartX, boardStartY;
		int bestScore;
		const std::string savePath ="save2048.txt";
		
		Sound moveSound, mergeSound, winSound, overSound, clickSound;
		
	    void initG();
	    void shutdownG();
		    
	    void handleInput();
		void updateGameOver( bool won );
		void updatePaused();
		void updateMenu();
		void updatePlaying(float dt);
			
	//	void draw();
		void drawMenu();
		void drawGameUI(int, int);
		void drawPaused();
		void drawGameOver( bool won );
			
		bool saveAll() const;
		bool loadAll();
		void updateBestScore();
		
		
		public:
			
			GameWrap(); 
		    ~GameWrap();
			
			void runG();
};
